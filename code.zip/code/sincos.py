import math

for i in range (0,32):
	print bin(int(math.sin(math.pi*i/16)*(2**15)))